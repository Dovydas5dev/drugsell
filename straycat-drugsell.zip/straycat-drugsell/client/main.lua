local ox_target = exports.ox_target

local function CreatePeds()
    for _, location in pairs(Config.Locations) do
        RequestModel(location.pedModel)

        while not HasModelLoaded(location.pedModel) do
            Wait(500)
        end

        local ped = CreatePed(4, location.pedModel, location.location, 0.0, false, true)
        SetEntityAsMissionEntity(ped, true, true)
        SetPedCanRagdoll(ped, false)
        SetBlockingOfNonTemporaryEvents(ped, true)
        FreezeEntityPosition(ped, true)
        SetEntityCanBeDamaged(ped, false)

        ox_target:addModel(location.pedModel, {
            {
                name = location.id .. '_drugsell_menu', 
                icon = 'fa-solid fa-sack-dollar',
                label = 'Talk with drug dealer',
                distance = 2,
                onSelect = function()
                    local playerJob = ESX.GetPlayerData().job.name 
                    if hasAccess(location.jobs, playerJob) then
                        StartConversation(location.items)
                    else
                        lib.notify({description = "You do not have permission to talk to the drug dealer.", type = "error"})
                    end
                end
            }
        })
    end
end

function hasAccess(allowedJobs, playerJob)
    for _, job in ipairs(allowedJobs) do
        if job == playerJob then
            return true
        end
    end
    return false
end

Citizen.CreateThread(function()
    CreatePeds()
end)

function StartConversation(items)
    lib.progressBar({
        duration = 3000,
        label = 'You are talking to a drug dealer...',
        useWhileDead = false,
        canCancel = false,
        disable = {
            move = true,
            car = true 
        }
    })
    OpenSellMenu(items)
end

function OpenSellMenu(items)
    local options = {}
    for _, item in ipairs(items) do
        table.insert(options, {
            title = item.label,
            description = 'Price: ' .. item.price .. ' $',
            event = 'drugsell:sellItem',
            args = { item = item.item, price = item.price }
        })
    end

    lib.registerContext({
        id = 'drugsell_menu',
        title = 'Drug dealer',
        options = options
    })

    lib.showContext('drugsell_menu')
end

RegisterNetEvent('drugsell:sellItem', function(data)
    TriggerServerEvent('drugsell:sellItem', data.item, data.price)
end)

RegisterNUICallback('menuClosed', function(data, cb)
    cb('ok')
end)
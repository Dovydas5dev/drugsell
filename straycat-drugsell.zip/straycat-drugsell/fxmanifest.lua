fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'StrayCat'

shared_scripts {'@ox_lib/init.lua', '@es_extended/imports.lua', 'shared.lua'}
client_script 'client/main.lua'
server_script 'server/main.lua'
Config = {}

Config.Locations = {
    {
        id = "narko", 
        location = vector4(721.8795, -2016.3575, 28.4318, 267.4903),
        pedModel = "a_m_y_cyclist_01",
        jobs = { 'police', 'mechanic' },
        items = {
            { label = "Water", item = "water", price = 10 },
            { label = "Burger", item = "burger", price = 11 },
        }
    },
}
ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('drugsell:sellItem')
AddEventHandler('drugsell:sellItem', function(item, price)
    local xPlayer = ESX.GetPlayerFromId(source)

    local itemCount = xPlayer.getInventoryItem(item).count
    if itemCount > 0 then
        local totalSale = itemCount * price
        xPlayer.removeInventoryItem(item, itemCount)
        xPlayer.addAccountMoney('black_money', totalSale) 
        TriggerClientEvent('ox_lib:notify', source, {type = 'success', description = 'You sold ' .. item .. ' for ' .. totalSale .. ' $' })
    else
        TriggerClientEvent('ox_lib:notify', source, {type = 'error', description = 'You don\'t have enough ' .. item })
    end
end)
